//
//  MonacoViewController.swift
//  
//
//  Created by Pavel Kasila on 20.03.21.
//

#if os(macOS)
import AppKit
public typealias ViewController = NSViewController
#else
import UIKit
public typealias ViewController = UIViewController
#endif
import WebKit


public enum MonacoEditorTypes: Int, Codable {
    case function = 1
    case constructor = 2
    case variable = 4
    case `class` = 5
    case interface = 7
    
    case property = 9
    case value = 13
    case constant = 14
    case `enum` = 15
    case enum_member = 16
    
    

    
}

struct MonacoSuggestion: Encodable {
    var label: String
    var kind: MonacoEditorTypes
    var documentation: String
    var insertText: String
    
    init(label: String, kind: MonacoEditorTypes, documentation: String, insertText: String) {
        self.label = "\(label)"
        self.kind = kind
        self.documentation = documentation
        self.insertText = insertText
    }
}

struct MonacoCompletionInput: Decodable {
    let lastBeforeDot: String
    let textUntilPosition: String
    let wordAtPosition: String
    let wordUntilPosition: String
}

public class MonacoViewController: ViewController, WKUIDelegate, WKNavigationDelegate {
    
    var delegate: MonacoViewControllerDelegate?
    
    var webView: WKWebView!
    
    public override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webConfiguration.userContentController.add(UpdateTextScriptHandler(self), name: "updateText")
        //webConfiguration.userContentController.add(TestScript(), name: "suggestions")
        //webConfiguration.userContentController.add(TestScript(), contentWorld: .page, name: "suggestions")
        webConfiguration.userContentController.addScriptMessageHandler(SuggestionScriptHandler(self), contentWorld: .page, name: "suggestions")
        webConfiguration.userContentController.add(SuggestionsHandler(self), name: "suggestions2")
        webConfiguration.userContentController.add(PrintObjectHandler(), name: "print_object")
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        #if os(iOS)
        webView.backgroundColor = .black
        #else
        webView.layer?.backgroundColor = .black
        #endif
        view = webView
        #if os(macOS)
        DistributedNotificationCenter.default.addObserver(self, selector: #selector(interfaceModeChanged(sender:)), name: NSNotification.Name(rawValue: "AppleInterfaceThemeChangedNotification"), object: nil)
        #endif
    }
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        loadMonaco()
    }
    
    private func loadMonaco() {
        let myURL = Bundle.module.url(forResource: "index", withExtension: "html", subdirectory: "Resources")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }
    func testSuggest() {
        evaluateJavascript("""
        (function(){
            testSuggest('')
        })()
        """)
    }
    // MARK: - Dark Mode
    private func updateTheme() {
        evaluateJavascript("""
        (function(){
            monaco.editor.setTheme('\(detectTheme())')
        })()
        """)
    }
    
    #if os(macOS)
    @objc private func interfaceModeChanged(sender: NSNotification) {
        updateTheme()
    }
    #else
    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        updateTheme()
    }
    #endif
    
    private func detectTheme() -> String {
        #if os(macOS)
        if UserDefaults.standard.string(forKey: "AppleInterfaceStyle") == "Dark" {
            return "vs-dark"
        } else {
            return "vs"
        }
        #else
        switch traitCollection.userInterfaceStyle {
            case .light, .unspecified:
                return "vs"
            case .dark:
                return "vs-dark"
            @unknown default:
                return "vs"
        }
        #endif
    }
    
    // MARK: - WKWebView
    public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Syntax Highlighting
        let syntax = self.delegate?.monacoView(getSyntax: self)

        let syntaxJS = syntax != nil ? """
        // Register a new language
        monaco.languages.register({ id: 'mySpecialLanguage' });

        // Register a tokens provider for the language
        monaco.languages.setMonarchTokensProvider('mySpecialLanguage', (function() {
            \(syntax!.configuration)
        })());
        

        
        
        """ : ""
        let syntaxJS2 = syntax != nil ? ", language: 'mySpecialLanguage'" : ""
        
        // Minimap
        let _minimap = self.delegate?.monacoView(getMinimap: self)
        let minimap = "minimap: { enabled: \(_minimap ?? true) }"
        
        // Scrollbar
        let _scrollbar = self.delegate?.monacoView(getScrollbar: self)
        let scrollbar = "scrollbar: { vertical: \(_scrollbar ?? true ? "\"visible\"" : "\"hidden\"") }"
        
        // Smooth Cursor
        let _smoothCursor = self.delegate?.monacoView(getSmoothCursor: self)
        let smoothCursor = "cursorSmoothCaretAnimation: \(_smoothCursor ?? false)"
        
        // Cursor Blinking
        let _cursorBlink = self.delegate?.monacoView(getCursorBlink: self)
        let cursorBlink = "cursorBlinking: \"\(_cursorBlink ?? .blink)\""
        
        // Font size
        let _fontSize = self.delegate?.monacoView(getFontSize: self)
        let fontSize = "fontSize: \(_fontSize ?? 12)"
        
        // Code itself
        let text = self.delegate?.monacoView(readText: self) ?? ""
        let b64 = text.data(using: .utf8)?.base64EncodedString()
        let javascript =
        """
        (function() {
        \(syntaxJS)
        
        editor.create(
            {
                value: atob('\(b64 ?? "")'), 
                automaticLayout: true,
                language: "python",
                theme: "\(detectTheme())"\(syntaxJS2), 
                \(minimap), 
                \(scrollbar), 
                \(smoothCursor), 
                \(cursorBlink), 
                \(fontSize)
            }
        );
        var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);
        
        return true;
        })();
        
        
        """
        //print(javascript)
        evaluateJavascript(javascript)
        //addSuggest()
    }
    
    public func addSuggest() {
        
        evaluateJavascript("""
        (function() {
        
            
            var j = [
                {
                    label: '"lodash"',
                    kind: 1,
                    documentation: "The Lodash library exported as Node.js modules.",
                    insertText: "lodash()",
                    
                },
                {
                    label: '"lodash2"',
                    kind: 1,
                    documentation: "The Lodash library exported as Node.js modules.",
                    insertText: 'def lodash2($0) -> str:\\n\\t',
                    parameters: [{
                        label: "ParamInfo1",
                        documentation: "this param does blah"
                    }]
                }
            ];
            editor.testSuggest(j);
        })();
        """)
        
    }
    
    private func evaluateJavascript(_ javascript: String) {
        
        webView.evaluateJavaScript(javascript, in: nil, in: WKContentWorld.page) {
          result in
          switch result {
          case .failure(let error):
            #if os(macOS)
            let alert = NSAlert()
            alert.messageText = "Error"
            alert.informativeText = "Something went wrong while evaluating \(error.localizedDescription): \(javascript)"
            alert.alertStyle = .critical
            alert.addButton(withTitle: "OK")
            alert.runModal()
            #else
            let alert = UIAlertController(title: "Error", message: "Something went wrong while evaluating \(error.localizedDescription)", preferredStyle: .alert)
            alert.addAction(.init(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            #endif
            break
          case .success(_):
            break
          }
        }
    }
}

// MARK: - Handler
let suggestions: [MonacoSuggestion] = (0...100).map({.init(label: "knob\($0)", kind: .class, documentation: "", insertText: "knob\($0)")})
let suggestionsJsonString = String(data: try! JSONEncoder().encode(suggestions), encoding: .utf8)!
let knobSuggestions: [MonacoSuggestion] = [
    .init(label: "value", kind: .property, documentation: "", insertText: "value"),
    .init(label: "color", kind: .property, documentation: "", insertText: "color")
]
let knobsJsonString = String(data: try! JSONEncoder().encode(knobSuggestions), encoding: .utf8)!
private extension MonacoViewController {
    
    final class SuggestionsHandler: NSObject, WKScriptMessageHandler {
        private weak var parent: MonacoViewController?
        
        init(_ parent: MonacoViewController) {
            self.parent = parent
        }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            print("SuggestionScriptHandler triggered")
            print(message.body)
            //DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            //print(message.body)
//            [
//                .init(label: "lodash", kind: .function, documentation: "", insertText: "lodash"),
//                .init(label: "lodash2", kind: .function, documentation: "", insertText: "lodash2")
//                
//            ]
            
            //print(jsonString)
            parent?.evaluateJavascript("""
            (function() {
                
                editor.testSuggest(\(suggestionsJsonString));
            })();
            """)
        }
        
        
    }
    
    final class SuggestionScriptHandler: NSObject, WKScriptMessageHandlerWithReply {
        
        private weak var parent: MonacoViewController?
        
        init(_ parent: MonacoViewController) {
            self.parent = parent
        }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
            print("SuggestionScriptHandler triggered")
            //DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                //print(message.body)
            parent?.evaluateJavascript("""
        (function() {
        
            
            var j = [
                {
                    label: '"lodash"',
                    kind: 1,
                    documentation: "The Lodash library exported as Node.js modules.",
                    insertText: "lodash()",
                    
                },
                {
                    label: '"lodash2"',
                    kind: 1,
                    documentation: "The Lodash library exported as Node.js modules.",
                    insertText: 'def lodash2($0) -> str:\\n\\t',
                    parameters: [{
                        label: "ParamInfo1",
                        documentation: "this param does blah"
                    }]
                }
            ];
            editor.testSuggest(j);
        })();
        """)
                replyHandler(
                    
                    [
                        "label": "\"lodash\"",
                        "kind": 1,
                        "documentation": "The Lodash library exported as Node.js modules.",
                        "insertText": "\"lodash\": \"*\"",
                        "range": message.body
                    ]
                    
                    ,nil)
            //}
        }
        
//        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) async -> (Any?, String?) {
//
//        }
        
        
    }
    
    final class PrintObjectHandler: NSObject, WKScriptMessageHandler {
  
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
//            guard let encodedText = message.body as? String else {
//                fatalError("Unexpected message body")
//            }
            
            print(message.body)
        }
    }
    
    final class UpdateTextScriptHandler: NSObject, WKScriptMessageHandler {
        private let parent: MonacoViewController

        init(_ parent: MonacoViewController) {
            self.parent = parent
        }

        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
            ) {
            guard let encodedText = message.body as? String,
            let data = Data(base64Encoded: encodedText),
            let text = String(data: data, encoding: .utf8) else {
                fatalError("Unexpected message body")
            }

            parent.delegate?.monacoView(controller: parent, textDidChange: text)
        }
    }
    
    final class TestScript: NSObject, WKScriptMessageHandler {
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let encodedText = message.body as? String,
                  let data = Data(base64Encoded: encodedText),
                  let text = String(data: data, encoding: .utf8) else {
                fatalError("Unexpected message body")
            }
            print("hello from \(text)")
        }
        
        
    }
    
    final class TestWithReply: NSObject, WKScriptMessageHandlerWithReply {
//        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
//
//        }
        
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) async -> (Any?, String?) {
            
            
            
            return (1,nil)
        }
        
        
    }
    
}

// MARK: - Delegate

public protocol MonacoViewControllerDelegate {
    func monacoView(readText controller: MonacoViewController) -> String
    func monacoView(getSyntax controller: MonacoViewController) -> SyntaxHighlight?
    func monacoView(getMinimap controller: MonacoViewController) -> Bool
    func monacoView(getScrollbar controller: MonacoViewController) -> Bool
    func monacoView(getSmoothCursor controller: MonacoViewController) -> Bool
    func monacoView(getCursorBlink controller: MonacoViewController) -> CursorBlink
    func monacoView(getFontSize controller: MonacoViewController) -> Int
    func monacoView(controller: MonacoViewController, textDidChange: String)
}
